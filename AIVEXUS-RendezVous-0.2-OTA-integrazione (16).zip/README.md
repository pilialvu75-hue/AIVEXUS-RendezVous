# AIVEXUS RendezVous — integration pilot 0.2.0 → 0.2.1

**Source integration, NOT a built APK.** This is a test-only pilot using fictional data. The original agenda HTML/JS is byte-identical to the tested 0.1.0. The 0.2 backend remains separate and is not connected to the Android UI by this change.

## Updater provenance
- Library: `pilialvu75-hue/AI-Orchestrator-Module-Library`, PR #397 merged 25 Nov 2026 at 10:37 UTC.
- Package `packages/aivexus_original_updater`, version `0.1.0-dev.1`, merge commit `c715ff93324371f923666a0766035b02b20530ea`.
- Source extraction commit from Riserva `5d5a3905ceced2c01c8f1d4a8c44ac75d9215fe0`.
- Git dependency pinned to merge commit. Library CI original regression reported success; no certification claimed.
- No alternate updater, no Beta Access. `UpdateChecker`, `UpdateManager`, `VersionComparator`, `AndroidIntentHandler` are imported from the actual module. Host provides native channels, file picker and French update panel only.

## Build (not executed here)
Install official stable Flutter + Android SDK, Java 17, Python 3. In a clean checkout run:
```
python prepare.py
python build-test-pair.py
```
On Windows use `py` if needed. A manual GitHub Actions workflow is included, producing both builds in one job using the same debug certificate; no releases are automatically published. This debug pair is for test only, not for distribution. Compare both signer SHA-256 values using `apksigner verify --print-certs`. The repository exists but the source has not been pushed. The environment has no Flutter/Android SDK and cannot reach GitHub from the build shell. The connector can read GitHub, but no file-transfer path for this local project was established.

## Publishing and device test
1. Verify compilation, APK signer, package `com.aivexus.rendezvous`, build numbers 2 and 3, and the actual APK SHA-256. The initial v0.1.0 demo used a different certificate, so a new debug pair generally requires uninstalling that demo once (local data will be erased); don't uninstall until the new APK has been built and is available. Use fictional data only.
2. Install 0.2.0, create a fictional appointment and a document. Before publishing the update, verify app functionality and absence of false update prompts.
3. Publish only the verified 0.2.1 APK as `rendezvous-0.2.1.apk` under tag `v0.2.1` in the dedicated repository. Publish generated `version.json` at `update/version.json` on main, after checking URL, size, version and digest.
4. Open 'Mises à jour' from the top bar. Check automatic detection (2-minute timer while running), manual detection, cancellation of consent, download progress, Android permission, explicit installer confirmation, actual post-install version and preservation of data.
5. Negative tests: no network, interruption/reopen, invalid APK, wrong signing certificate, wrong package, downgrade/equal build. Never bypass signature checks. The host blocks mismatched signing certificate/package, rejects non-increasing build code, limits native download to RendezVous GitHub release URLs, checks the staging-copy digest. Original Android manifest parser does NOT expose an expected APK SHA-256 field; recording the SHA-256 in the release template is not proof of matching it at runtime. The module owner should address this separately before certification. Android package-manager verification and signer matching must be tested on-device. No cryptographically signed manifest or rollback implemented by this host.
6. The test-only debug signer must NOT be used for production; a separately managed protected signing key is necessary for production.

## Verified here
- Original scheduling engine tests: 7/7.
- Existing server HTTP tests: 8/8 (separate backend).
- Original HTML/JS byte-for-byte unchanged.
- Python build scripts parse successfully.
- No Flutter analysis/build, Android execution, remote publication or OTA execution in this environment.
