"""Build two APKs using the same Flutter debug key. No automatic publication."""
import pathlib, argparse, subprocess, shutil, hashlib, json, re
p=argparse.ArgumentParser();p.add_argument('--project',default='generated');p.add_argument('--out',default='test-pair');a=p.parse_args()
base=pathlib.Path(a.project).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(exist_ok=False,parents=True)
subprocess.run(['flutter','pub','get'],cwd=base,check=True)
subprocess.run(['flutter','analyze','--no-fatal-infos','--no-fatal-warnings'],cwd=base,check=True)
for version,code in [('0.2.0',2),('0.2.1',3)]:
    subprocess.run(['flutter','build','apk','--debug','--build-name',version,'--build-number',str(code)],cwd=base,check=True)
    shutil.copyfile(base/'build/app/outputs/flutter-apk/app-debug.apk',out/f'rendezvous-{version}.apk')
# A manifest template: publish only after verifying both APK signatures and installation.
f=out/'rendezvous-0.2.1.apk'; digest=hashlib.sha256(f.read_bytes()).hexdigest();size=f.stat().st_size
url='https://github.com/pilialvu75-hue/AIVEXUS-RendezVous/releases/download/v0.2.1/rendezvous-0.2.1.apk'
m={'version':'0.2.1','versionName':'0.2.1','versionCode':3,'channel':'stable','min_supported':'0.2.0','apk_url':url,'apkUrl':url,'sha256':digest,'apk_sha256':digest,'apk_size_bytes':size,'changelog':'Pilote OTA AIVEXUS Original Updater','forceUpdate':False,'critical':False}
(out/'version.json').write_text(json.dumps(m,indent=2)+'\n');print('Verify with apksigner verify --print-certs for both APKs before publication.')
