"""Generate official Flutter Android scaffold then overlay RendezVous source.
Run in a clean checkout with Flutter and the Android SDK installed.
"""
import argparse, pathlib, shutil, subprocess, xml.etree.ElementTree as ET
BASE=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--out',default='generated');a=p.parse_args();out=pathlib.Path(a.out).resolve()
if out.exists(): raise SystemExit('Output already exists; choose a fresh directory')
subprocess.run(['flutter','create','--platforms=android','--org','com.aivexus','--project-name','rendezvous',str(out)],check=True)
# Preserve the installed Android package and WebView origin. The app label is changed below.
shutil.copytree(BASE/'overlay',out,dirs_exist_ok=True)
# Generated Flutter example tests target the deleted demo widget.
shutil.rmtree(out/'test',ignore_errors=True)
android=out/'android/app';manifest=android/'src/main/AndroidManifest.xml'
ns='http://schemas.android.com/apk/res/android';ET.register_namespace('android',ns);q=lambda k:f'{{{ns}}}{k}'
tree=ET.parse(manifest);root=tree.getroot();app=root.find('application');assert app is not None
for name in ('android.permission.INTERNET','android.permission.REQUEST_INSTALL_PACKAGES'):
    ET.SubElement(root,'uses-permission',{q('name'):name})
app.set(q('label'),'AIVEXUS RendezVous');app.set(q('allowBackup'),'false');app.set(q('usesCleartextTraffic'),'false')
ET.SubElement(ET.SubElement(app,'provider',{q('name'):'androidx.core.content.FileProvider',q('authorities'):'${applicationId}.fileprovider',q('exported'):'false',q('grantUriPermissions'):'true'}),'meta-data',{q('name'):'android.support.FILE_PROVIDER_PATHS',q('resource'):'@xml/ota_paths'})
tree.write(manifest,encoding='utf-8',xml_declaration=True)
# Flutter stable templates currently use Kotlin DSL. Fail clearly on unexpected layout.
gradle=android/'build.gradle.kts'
if not gradle.is_file(): raise SystemExit('Kotlin Gradle template expected; inspect generated scaffold')
s=gradle.read_text();assert 'com.aivexus.rendezvous' in s, 'unexpected app identity'
s+='\ndependencies { implementation("androidx.core:core-ktx:1.13.1") }\n';gradle.write_text(s)
# Remove other generated entrypoint only if it exists in a different namespace.
assert (android/'src/main/kotlin/com/aivexus/rendezvous/MainActivity.kt').is_file()
print(out)
