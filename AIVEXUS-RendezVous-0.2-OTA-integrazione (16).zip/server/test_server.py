import os,tempfile,unittest,threading,datetime as dt,json,urllib.request,urllib.error,base64,concurrent.futures
with tempfile.TemporaryDirectory() as directory:
 os.environ['RV_DB']=directory+'/test.sqlite'
 for name in ('ADMIN','CLIENT1','CLIENT2'):os.environ['RV_'+name+'_PASSWORD']='Test-'+name+'-123456'
 import server as s
 s.init(); srv=s.ThreadingHTTPServer(('127.0.0.1',0),s.Handler); threading.Thread(target=srv.serve_forever,daemon=True).start()
 def api(path,body=None,token=None):
  req=urllib.request.Request(f'http://127.0.0.1:{srv.server_port}/api/'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+(token or '')})
  try:
   with urllib.request.urlopen(req) as r:return r.status,json.load(r)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 def login(name):return api('login',{'login':name,'password':'Test-'+name.upper()+'-123456'})[1]
 admin,c1,c2=[login(n) for n in ('admin','client1','client2')]; a,b,c=[u['token'] for u in (admin,c1,c2)]; cl=c1['user']['id']; other=c2['user']['id']; day=dt.datetime.now(s.ZONE).date()+dt.timedelta(days=2)
 while day.weekday()>=5:day+=dt.timedelta(days=1)
 day=day.isoformat(); doc={'name':'fictif.txt','mime':'text/plain','data':base64.b64encode(b'fiction').decode()}
 class Tests(unittest.TestCase):
  def test_01_auth(self):
   self.assertEqual(api('appointments')[0],401);self.assertEqual(api('login',{'login':'admin','password':'incorrect'})[0],401);self.assertEqual(api('clients',token=b)[0],403);self.assertEqual(api('clients',token=a)[0],200)
  def test_02_concurrent(self):
   with concurrent.futures.ThreadPoolExecutor() as pool: res=list(pool.map(lambda t:api('book',{'kind':'consultation','day':day,'start':540},t)[0],[b,c]))
   self.assertEqual(sorted(res),[200,409]);self.assertNotIn(585,api('slots?kind=maintenance&day='+day,token=c)[1]);self.assertIn(630,api('slots?kind=maintenance&day='+day,token=c)[1])
  def test_03_booking_doc_and_isolation(self):
   self.assertEqual(api('book',{'kind':'adaptation','day':day,'start':840,'document':doc},b)[0],200); x=api('documents',token=b)[1][0];self.assertEqual(api('document?id='+x['id'],token=c)[0],404);self.assertEqual(api('document?id='+x['id'],token=a)[1]['data'],doc['data']); self.assertEqual(api('documents?client='+cl,token=c)[0],403); self.assertEqual(api('book',{'kind':'maintenance','day':day,'start':975,'client':other},b)[0],403)
  def test_04_move_cancel(self):
   ap=next(x for x in api('appointments',token=b)[1] if x['kind']=='adaptation');id=ap['id'];self.assertEqual(api('move',{'id':id,'day':day,'start':855},b)[0],403);self.assertEqual(api('move',{'id':id,'day':day,'start':855},a)[0],200);self.assertEqual(api('cancel',{'id':id},c)[0],404);self.assertEqual(api('cancel',{'id':id},b)[0],200);self.assertIn(840,api('slots?kind=adaptation&day='+day,token=b)[1]);self.assertTrue(any(x['kind']=='move' for x in api('events',token=b)[1]))
  def test_05_exchange(self):
   self.assertEqual(api('messages',{'body':'bonjour','client':cl},a)[0],200);self.assertEqual(api('messages',{'body':'merci'},b)[0],200);self.assertEqual(len(api('messages?client='+cl,token=a)[1]),2);self.assertEqual(api('messages',token=c)[1],[]);self.assertEqual(api('documents',{'client':cl,'document':doc},a)[0],200);self.assertEqual(len(api('documents',token=b)[1]),2);self.assertEqual(api('documents',{'document':{**doc,'mime':'text/html'}},b)[0],400)
  def test_06_atomic_attach(self):
   self.assertEqual(api('book',{'kind':'maintenance','day':day,'start':840,'document':{**doc,'data':'INVALID'}},b)[0],400);self.assertIn(840,api('slots?kind=maintenance&day='+day,token=b)[1])
  def test_07_reminder_and_read(self):
   with s.connect() as db:
    ap=db.execute("SELECT * FROM appointments WHERE status='confirmed' LIMIT 1").fetchone(); instant=dt.datetime.combine(dt.date.fromisoformat(ap['day']),dt.time(ap['start']//60,ap['start']%60),s.ZONE);s.reminders(db,instant-dt.timedelta(hours=20));s.reminders(db,instant-dt.timedelta(hours=20));s.reminders(db,instant-dt.timedelta(hours=1));s.reminders(db,instant-dt.timedelta(hours=1));self.assertEqual(db.execute("SELECT count(*) FROM events WHERE kind='reminder'").fetchone()[0],2)
   token=b if ap['client']==cl else c; ev=next(x for x in api('events',token=token)[1] if x['kind']=='reminder');self.assertEqual(api('seen',{'id':ev['id']},token)[0],200);self.assertEqual(next(x for x in api('events',token=token)[1] if x['id']==ev['id'])['seen'],1)
  def test_08_persistence_and_logout(self):
   s.init();self.assertTrue(api('appointments',token=a)[1]);self.assertEqual(api('logout',{},c)[0],200);self.assertEqual(api('appointments',token=c)[0],401)
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests);result=unittest.TextTestRunner(verbosity=2).run(suite);srv.shutdown();raise SystemExit(not result.wasSuccessful())
