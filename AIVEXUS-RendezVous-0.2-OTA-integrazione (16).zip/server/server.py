"""RendezVous test server. Standard library only. Fictional data only."""
import base64, datetime as dt, hashlib, hmac, json, os, re, secrets, sqlite3, time, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from zoneinfo import ZoneInfo
DB=os.environ.get('RV_DB',str(Path(__file__).with_name('demo.sqlite')))
ZONE=ZoneInfo('Europe/Paris'); LIMIT=2*1024*1024
TYPES={'maintenance':('Entretien',45),'consultation':('Première consultation',90),'adaptation':('Adaptation complète',135)}
def connect():
 c=sqlite3.connect(DB,timeout=15,isolation_level=None); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c
def uid(): return secrets.token_hex(16)
def digest(s): return hashlib.sha256(s.encode()).hexdigest()
def password(s,salt): return hashlib.pbkdf2_hmac('sha256',s.encode(),bytes.fromhex(salt),310000).hex()
def init():
 with connect() as c:
  c.executescript('''PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT NOT NULL,login TEXT UNIQUE NOT NULL,role TEXT CHECK(role IN ('admin','client')),salt TEXT NOT NULL,pw TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user TEXT REFERENCES users(id), expires INTEGER);
 CREATE TABLE IF NOT EXISTS appointments(id TEXT PRIMARY KEY,client TEXT REFERENCES users(id),kind TEXT,day TEXT,start INTEGER,duration INTEGER,status TEXT,revision INTEGER DEFAULT 1);
 CREATE TABLE IF NOT EXISTS docs(id TEXT PRIMARY KEY,client TEXT REFERENCES users(id),sender TEXT REFERENCES users(id),name TEXT,mime TEXT,data BLOB,appointment TEXT REFERENCES appointments(id),created INTEGER);
 CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,client TEXT REFERENCES users(id),sender TEXT REFERENCES users(id),body TEXT,created INTEGER);
 CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,recipient TEXT REFERENCES users(id),kind TEXT,body TEXT,created INTEGER,seen INTEGER DEFAULT 0,dedupe TEXT UNIQUE);
 ''')
  for name,role in [('admin','admin'),('client1','client'),('client2','client')]:
   if not c.execute('SELECT 1 FROM users WHERE login=?',(name,)).fetchone():
    pw=os.environ.get('RV_'+name.upper()+'_PASSWORD')
    if not pw: raise RuntimeError('Set RV_'+name.upper()+'_PASSWORD (fictional test account)')
    if len(pw)<12: raise RuntimeError('Minimum 12 characters')
    salt=secrets.token_hex(16); c.execute('INSERT INTO users VALUES(?,?,?,?,?,?)',(uid(),name,name,role,salt,password(pw,salt)))
def rows(c,q,p=()): return [dict(x) for x in c.execute(q,p)]
class Problem(Exception):
 def __init__(self,status,msg): self.status=status; self.msg=msg

def require(ok,status,msg):
 if not ok: raise Problem(status,msg)
def client_id(c,u,requested=None):
 if u['role']=='client':
  require(requested in (None,u['id']),403,'Accès refusé'); return u['id']
 require(bool(requested) and c.execute("SELECT 1 FROM users WHERE id=? AND role='client'",(requested,)).fetchone(),400,'Client requis'); return requested

def event(c,recipient,kind,body,key=None):
 c.execute('INSERT OR IGNORE INTO events(id,recipient,kind,body,created,dedupe) VALUES(?,?,?,?,?,?)',(uid(),recipient,kind,body,int(time.time()),key))
def notify(c,client,kind,body,actor=None):
 for r in c.execute("SELECT id FROM users WHERE role='admin' OR id=?",(client,)):
  if r['id']!=actor: event(c,r['id'],kind,body)
def slot(c,day,start,duration,exclude=None):
 require(isinstance(day,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',day),400,'Date invalide')
 try: d=dt.date.fromisoformat(day)
 except ValueError: raise Problem(400,'Date invalide')
 now=dt.datetime.now(ZONE); require(d>=now.date(),400,'Date passée')
 require(type(start)==int and start%15==0 and (d>now.date() or start>now.hour*60+now.minute),400,'Horaire invalide')
 require(d.weekday()<5 and any(a<=start and start+duration<=b for a,b in [(540,720),(840,1080)]),409,'Créneau fermé')
 require(not c.execute("SELECT 1 FROM appointments WHERE day=? AND status='confirmed' AND start<? AND start+duration>? AND id<>?",(day,start+duration,start,exclude or '')).fetchone(),409,'Créneau occupé')
def doc(c,u,client,d,appointment=None):
 require(isinstance(d,dict),400,'Document invalide')
 name=d.get('name',''); mime=d.get('mime',''); require(isinstance(name,str) and 0<len(name)<=180 and not re.search(r'[\\/\x00-\x1f]',name),400,'Nom invalide')
 require(mime in ['application/pdf','image/png','image/jpeg','text/plain'],400,'Type non accepté')
 try: b=base64.b64decode(d.get('data',''),validate=True)
 except Exception: raise Problem(400,'Fichier invalide')
 require(0<len(b)<=LIMIT,400,'Taille invalide')
 require((mime=='application/pdf' and b.startswith(b'%PDF-')) or (mime=='image/png' and b.startswith(b'\x89PNG\r\n\x1a\n')) or (mime=='image/jpeg' and b.startswith(b'\xff\xd8\xff')) or (mime=='text/plain' and b'\x00' not in b),400,'Contenu invalide')
 if mime=='text/plain':
  try: b.decode('utf-8')
  except UnicodeError: raise Problem(400,'Texte UTF-8 requis')
 id=uid(); c.execute('INSERT INTO docs VALUES(?,?,?,?,?,?,?,?)',(id,client,u['id'],name,mime,b,appointment,int(time.time()))); notify(c,client,'document','Nouveau document disponible',u['id']); return id

def reminders(c,now=None):
 now=now or dt.datetime.now(ZONE)
 for a in c.execute("SELECT * FROM appointments WHERE status='confirmed' AND day>=?",(now.date().isoformat(),)):
  start=dt.datetime.combine(dt.date.fromisoformat(a['day']),dt.time(a['start']//60,a['start']%60),ZONE)
  delta=(start.astimezone(dt.timezone.utc)-now.astimezone(dt.timezone.utc)).total_seconds()
  for hours in (24,2):
   if 0<delta<=hours*3600 and (hours==2 or delta>2*3600):
    event(c,a['client'],'reminder',f'Rappel : rendez-vous dans moins de {hours} h.',f"{a['id']}:{a['revision']}:{hours}")
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args): pass
 def send_json(self,status,p):
  b=json.dumps(p,ensure_ascii=False).encode(); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
 def do_GET(self): self.handle_api('GET')
 def do_POST(self): self.handle_api('POST')
 def handle_api(self,method):
  from urllib.parse import urlsplit,parse_qs
  p=urlsplit(self.path); q={k:v[0] for k,v in parse_qs(p.query).items()}; c=connect()
  try:
   if method=='GET' and p.path=='/':
    b=Path(__file__).with_name('index.html').read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
   d={}
   if method=='POST':
    n=int(self.headers.get('Content-Length','0')); require(0<n<=3*1024*1024,413,'Requête trop grande'); d=json.loads(self.rfile.read(n)); require(isinstance(d,dict),400,'Objet requis')
   c.execute('BEGIN IMMEDIATE') # serializes all mutation and slot validation
   if p.path=='/api/login' and method=='POST':
    u=c.execute('SELECT * FROM users WHERE login=?',(d.get('login'),)).fetchone(); pw=d.get('password',''); require(isinstance(pw,str) and len(pw)<=256,400,'Mot de passe invalide'); require(u and hmac.compare_digest(u['pw'],password(pw,u['salt'])),401,'Identifiants invalides'); token=secrets.token_urlsafe(32); c.execute('INSERT INTO sessions VALUES(?,?,?)',(digest(token),u['id'],int(time.time())+8*3600)); result={'token':token,'user':{k:u[k] for k in ('id','name','role')}}
   else:
    auth=self.headers.get('Authorization',''); require(auth.startswith('Bearer '),401,'Connexion requise'); token=digest(auth[7:]); u=c.execute('SELECT users.* FROM users JOIN sessions ON users.id=sessions.user WHERE sessions.token=? AND expires>?',(token,int(time.time()))).fetchone(); require(u,401,'Session expirée'); result=self.route(c,u,p.path,method,d,q,token)
   c.commit(); self.send_json(200,result)
  except Problem as e: c.rollback(); self.send_json(e.status,{'error':e.msg})
  except (ValueError,TypeError,KeyError,OverflowError): c.rollback(); self.send_json(400,{'error':'Requête invalide'})
  except Exception: c.rollback(); self.send_json(500,{'error':'Erreur serveur'})
  finally: c.close()
 def route(self,c,u,p,m,d,q,token):
  admin=u['role']=='admin'; me=u['id']; client=d.get('client') if m=='POST' else q.get('client'); id=d.get('id') if m=='POST' else q.get('id')
  if p=='/api/logout' and m=='POST': c.execute('DELETE FROM sessions WHERE token=?',(token,)); return {'ok':True}
  if p=='/api/clients' and m=='GET':
   require(admin,403,'Accès refusé'); return rows(c,"SELECT id,name FROM users WHERE role='client'")
  if p=='/api/types' and m=='GET': return [{'id':k,'name':v[0],'duration':v[1]} for k,v in TYPES.items()]
  if p=='/api/slots' and m=='GET':
   kind=q.get('kind'); require(kind in TYPES,400,'Motif invalide'); day=q.get('day'); result=[]
   for s in range(540,1080,15):
    try: slot(c,day,s,TYPES[kind][1]); result.append(s)
    except Problem: pass
   return result
  if p=='/api/appointments' and m=='GET':
   if admin: return rows(c,'SELECT * FROM appointments ORDER BY day,start')
   return rows(c,'SELECT * FROM appointments WHERE client=? ORDER BY day,start',(me,))
  if p=='/api/book' and m=='POST':
   cl=client_id(c,u,client); kind=d.get('kind'); require(kind in TYPES,400,'Motif invalide'); dur=TYPES[kind][1]; day=d.get('day'); start=d.get('start'); slot(c,day,start,dur); id=uid(); c.execute("INSERT INTO appointments VALUES(?,?,?,?,?,?, 'confirmed',1)",(id,cl,kind,day,start,dur));
   if d.get('document'): doc(c,u,cl,d['document'],id)
   notify(c,cl,'booking','Nouveau rendez-vous confirmé'); return {'id':id}
  if p in ('/api/move','/api/cancel') and m=='POST':
   a=c.execute('SELECT * FROM appointments WHERE id=?',(id,)).fetchone(); require(a and (admin or a['client']==me),404,'Rendez-vous introuvable'); require(a['status']=='confirmed',409,'Rendez-vous annulé')
   if p.endswith('move'):
    require(admin,403,'Accès refusé'); slot(c,d.get('day'),d.get('start'),a['duration'],id); c.execute('UPDATE appointments SET day=?,start=?,revision=revision+1 WHERE id=?',(d['day'],d['start'],id)); kind='move'
   else: c.execute("UPDATE appointments SET status='cancelled',revision=revision+1 WHERE id=?",(id,)); kind='cancel'
   c.execute("DELETE FROM events WHERE seen=0 AND kind='reminder' AND dedupe LIKE ?",(id+':%',)); notify(c,a['client'],kind,'Rendez-vous '+('déplacé' if kind=='move' else 'annulé')); return {'ok':True}
  if p in ('/api/documents','/api/messages'):
   cl=client_id(c,u,client); table='docs' if p.endswith('documents') else 'messages'
   if m=='GET': return rows(c,'SELECT id,client,sender,name,mime,length(data) AS size,appointment,created FROM docs WHERE client=? ORDER BY created DESC' if table=='docs' else 'SELECT * FROM messages WHERE client=? ORDER BY created DESC',(cl,))
   if table=='docs': return {'id':doc(c,u,cl,d.get('document'))}
   body=d.get('body'); require(isinstance(body,str) and 0<len(body.strip())<=2000,400,'Message invalide'); id=uid(); c.execute('INSERT INTO messages VALUES(?,?,?,?,?)',(id,cl,me,body,int(time.time()))); notify(c,cl,'message','Nouveau message',me); return {'id':id}
  if p=='/api/document' and m=='GET':
   x=c.execute('SELECT * FROM docs WHERE id=?',(id,)).fetchone(); require(x and (admin or x['client']==me),404,'Document introuvable'); return {'name':x['name'],'mime':x['mime'],'data':base64.b64encode(x['data']).decode()}
  if p=='/api/events' and m=='GET': reminders(c); return rows(c,'SELECT id,kind,body,created,seen FROM events WHERE recipient=? ORDER BY created DESC',(me,))
  if p=='/api/seen' and m=='POST': c.execute('UPDATE events SET seen=1 WHERE recipient=? AND id=?',(me,id)); return {'ok':True}
  raise Problem(404,'Route inconnue')
def reminder_worker(stop):
 while not stop.is_set():
  c=connect()
  try:
   c.execute('BEGIN IMMEDIATE'); reminders(c); c.commit()
  except Exception:
   c.rollback()
   print('Reminder worker error',flush=True)
  finally: c.close()
  stop.wait(30)
def serve():
 init(); stop=threading.Event(); threading.Thread(target=reminder_worker,args=(stop,),daemon=True).start(); server=ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('RV_PORT','8765'))),Handler); print('Test local : http://127.0.0.1:'+str(server.server_port),flush=True); server.serve_forever()
if __name__=='__main__': serve()
