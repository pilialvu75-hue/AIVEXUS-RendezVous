package com.aivexus.rendezvous

import android.app.DownloadManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.View
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import java.io.File
import java.security.MessageDigest

// Host adapter only: update selection, download orchestration, verification and
// state machine remain in the pinned original Dart module.
class MainActivity : FlutterActivity() {
    private var pending: ValueCallback<Array<Uri>>? = null
    private var installerLaunched: Boolean? = null
    private var installerResult: Int? = null
    private var installerError: String? = null
    private val chooserCode = 881
    private val installCode = 9917
    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        engine.platformViewsController.registry.registerViewFactory("rendezvous/agenda", object : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
            override fun create(context: Context, viewId: Int, args: Any?): PlatformView {
                val web = WebView(context)
                web.settings.javaScriptEnabled = true
                web.settings.domStorageEnabled = true
                web.settings.allowFileAccess = false
                web.webChromeClient = object : WebChromeClient() {
                    override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                        pending?.onReceiveValue(null); pending = callback
                        try { startActivityForResult(params.createIntent(), chooserCode) }
                        catch(e: Exception) { pending?.onReceiveValue(null); pending = null }
                        return true
                    }
                }
                web.loadUrl("file:///android_asset/index.html")
                return object : PlatformView {
                    override fun getView(): View = web
                    override fun dispose() { web.destroy() }
                }
            }
        })
        registerDownloads(engine)
        MethodChannel(engine.dartExecutor.binaryMessenger, "com.aiorchestrator/android_intents").setMethodCallHandler { call, result ->
            try {
                when(call.method) {
                    "getInstallDiagnostics" -> {
                        val info = installed()
                        result.success(mapOf("sdkInt" to Build.VERSION.SDK_INT, "canRequestPackageInstalls" to canInstall(),
                            "applicationId" to packageName, "installedVersionName" to info.versionName,
                            "installedVersionCode" to version(info), "installedSignatureSha256" to signature(info),
                            "installerPackageName" to installerPackage(), "lastInstallerLaunchSuccess" to installerLaunched,
                            "lastInstallerException" to installerError, "lastInstallerResultCode" to installerResult))
                    }
                    "verifyApk" -> result.success(verify(privateFile(requireNotNull(call.argument<String>("apkPath")))))
                    "openUnknownAppsSettings" -> { openSettings(); result.success(true) }
                    "openApkInstaller", "installApk" -> {
                        val file = privateFile(requireNotNull(call.argument<String>("apkPath")))
                        launchInstaller(file); result.success(true)
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                if (call.method == "openApkInstaller" || call.method == "installApk") { installerLaunched = false; installerError = e.message }
                result.error("RENDEZVOUS_OTA", e.message, null)
            }
        }
    }
    private fun privateFile(path: String): File {
        val f = File(path).canonicalFile
        val roots = listOfNotNull(filesDir, cacheDir, getExternalFilesDir(null), File(applicationInfo.dataDir, "app_flutter"))
        require(roots.any { f.path.startsWith(it.canonicalPath + File.separator) }) { "APK outside app-private storage" }
        return f
    }
    private fun canInstall() = Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls()
    private fun openSettings() { if (Build.VERSION.SDK_INT >= 26) startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))) }
    @Suppress("DEPRECATION") private fun flags() = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
    @Suppress("DEPRECATION") private fun installed() = packageManager.getPackageInfo(packageName, flags())
    @Suppress("DEPRECATION") private fun version(p: PackageInfo) = if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()
    @Suppress("DEPRECATION") private fun installerPackage(): String? = try { if (Build.VERSION.SDK_INT >= 30) packageManager.getInstallSourceInfo(packageName).installingPackageName else packageManager.getInstallerPackageName(packageName) } catch (_: Exception) { null }
    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it) }
    @Suppress("DEPRECATION") private fun signature(p: PackageInfo): String? {
        val signers = if (Build.VERSION.SDK_INT >= 28) p.signingInfo?.apkContentsSigners else p.signatures
        val first = signers?.singleOrNull() ?: return null
        return MessageDigest.getInstance("SHA-256").digest(first.toByteArray()).joinToString(":") { "%02X".format(it) }
    }
    private fun digest(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { stream -> val b = ByteArray(32768); while (true) { val n = stream.read(b); if (n <= 0) break; md.update(b,0,n) } }
        return hex(md.digest())
    }
    @Suppress("DEPRECATION") private fun verify(f: File): Map<String, Any?> {
        val readable = f.isFile && f.canRead(); val ext = f.name.endsWith(".apk", true)
        val p = if(readable && ext) packageManager.getPackageArchiveInfo(f.path, flags()) else null
        val split = !p?.splitNames.isNullOrEmpty() || f.name.contains("split_config.", true) || f.name.startsWith("config.", true)
        val sig = p?.let { signature(it) }; val valid = readable && ext && f.length()>0 && p != null && !split && sig != null
        return mapOf("valid" to valid, "exists" to f.exists(), "readable" to readable, "hasApkExtension" to ext,
            "sizeBytes" to f.length(), "packageName" to p?.packageName, "versionName" to p?.versionName,
            "versionCode" to p?.let { version(it) }, "signatureSha256" to sig,
            "fileSha256" to if (readable) digest(f) else null, "hasSplitConfig" to split, "archiveParsed" to (p != null),
            "abi" to if(f.name.contains("arm64-v8a")) "arm64-v8a" else if(f.name.contains("x86_64")) "x86_64" else null,
            "reason" to if(valid) "ok" else "invalid_archive")
    }
    private fun launchInstaller(f: File) {
        val v = verify(f); val current = installed()
        require(v["valid"] == true && v["packageName"] == packageName && v["signatureSha256"] != null && v["signatureSha256"] == signature(current)) { "APK identity or certificate mismatch" }
        require((v["versionCode"] as Long) > version(current)) { "Downgrade or equal build rejected" }
        if(!canInstall()) { openSettings(); error("Autorisez l'installation puis réessayez") }
        val target = File(cacheDir, "apk-installer/candidate.apk"); target.parentFile!!.mkdirs()
        if(f.canonicalFile != target.canonicalFile) f.copyTo(target, overwrite = true)
        require(digest(target) == v["fileSha256"]) { "Staging digest mismatch" }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", target)
        val intent = Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra(Intent.EXTRA_RETURN_RESULT, true)
            clipData = ClipData.newUri(contentResolver, "apk", uri)
        }
        installerResult = null; startActivityForResult(intent, installCode); installerLaunched = true; installerError = null
    }
    @Deprecated("Android activity result API") override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == chooserCode) { pending?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); pending = null }
        if(requestCode == installCode) installerResult = resultCode
    }
    private fun registerDownloads(engine: FlutterEngine) {
        val app = applicationContext
        val manager = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val prefs = app.getSharedPreferences("background_downloads_v1", Context.MODE_PRIVATE)
        MethodChannel(engine.dartExecutor.binaryMessenger, "ai_orchestrator/background_downloads").setMethodCallHandler { call, result ->
            try {
                val url = requireNotNull(call.argument<String>("url")); val uri = Uri.parse(url)
                require(uri.scheme == "https" && uri.host == "github.com" && uri.path.orEmpty().startsWith("/pilialvu75-hue/AIVEXUS-RendezVous/releases/download/")) { "Untrusted download endpoint" }
                val key = hex(MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8)))
                val root = requireNotNull(app.getExternalFilesDir("background_downloads")); val file = File(root,"$key.download")
                var id = prefs.getLong(key,-1)
                fun snapshot(): Map<String, Any>? {
                    if(id < 0) return null
                    manager.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                        if(!c.moveToFirst()) return null
                        fun n(s: String) = c.getLong(c.getColumnIndexOrThrow(s))
                        return mapOf("status" to n(DownloadManager.COLUMN_STATUS), "reason" to n(DownloadManager.COLUMN_REASON), "received" to n(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR), "total" to n(DownloadManager.COLUMN_TOTAL_SIZE_BYTES), "path" to file.absolutePath)
                    }; return null
                }
                when(call.method) {
                    "start" -> {
                        val old = snapshot()
                        if(old == null || old["status"] == 16L || (old["status"] == 8L && !file.isFile)) {
                            if(id >= 0) manager.remove(id); root.mkdirs(); if(file.exists()) check(file.delete())
                            val request = DownloadManager.Request(uri).setTitle("AIVEXUS RendezVous").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED).setDestinationInExternalFilesDir(app,"background_downloads",file.name).setAllowedOverMetered(true).setAllowedOverRoaming(false).addRequestHeader("Accept-Encoding","identity")
                            id = manager.enqueue(request); if(!prefs.edit().putLong(key,id).commit()) { manager.remove(id); error("Cannot persist download") }
                        }; result.success(snapshot())
                    }
                    "status" -> result.success(snapshot())
                    "cancel", "release" -> { if(id>=0) manager.remove(id); file.delete(); prefs.edit().remove(key).commit(); result.success(null) }
                    else -> result.notImplemented()
                }
            } catch(e: Exception) { result.error("BACKGROUND_DOWNLOAD",e.message,null) }
        }
    }
}
