(function(root){
 const minutes=s=>{const [h,m]=s.split(':').map(Number);return h*60+m};
 const hh=m=>`${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
 const validDate=d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&!isNaN(Date.parse(d+'T12:00:00'));
 function slots(db,date,duration,exclude){if(!validDate(date)||![45,90,135].includes(duration))return [];const weekday=new Date(date+'T12:00:00').getDay(); if(!db.days.includes(weekday))return []; const busy=[...db.appointments.filter(a=>a.date===date&&a.id!==exclude&&a.status!=='cancelled'),...db.blocks.filter(a=>a.date===date)];let result=[];const now=new Date();const today=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;if(date<today)return []; for(const [start,end] of db.hours){for(let t=minutes(start);t+duration<=minutes(end);t+=15){if(date===today&&t<now.getHours()*60+now.getMinutes())continue;if(!busy.some(a=>t<a.start+a.duration&&t+duration>a.start))result.push(t)}}return [...new Set(result)].sort((a,b)=>a-b)}
 function reserve(db,a){if(!slots(db,a.date,a.duration,a.id).includes(a.start))throw Error('Ce créneau n’est plus disponible.');const existing=db.appointments.find(x=>x.id===a.id);if(existing)Object.assign(existing,a);else db.appointments.push(a);return a}
 function init(){return {days:[1,2,3,4,5,6],hours:[['09:00','12:00'],['14:00','18:00']],types:[{id:'service',name:'Entretien / réglage',duration:45},{id:'first',name:'Premier rendez-vous',duration:90},{id:'fit',name:'Adaptation complète',duration:135}],appointments:[],blocks:[],docs:[],messages:[]}}
 const core={minutes,hh,slots,reserve,init};if(typeof module!=='undefined')module.exports=core;else root.Core=core;
})(typeof window==='undefined'?globalThis:window);
