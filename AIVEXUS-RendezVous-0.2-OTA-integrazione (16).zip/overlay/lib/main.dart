import 'package:flutter/material.dart';
import 'package:aivexus_original_updater/aivexus_original_updater.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:package_info_plus/package_info_plus.dart';

const repository = 'AIVEXUS-RendezVous';
const manifest = 'https://raw.githubusercontent.com/pilialvu75-hue/$repository/main/update/version.json';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final info = await PackageInfo.fromPlatform();
  final client = http.Client();
  const comparator = VersionComparator();
  final checker = UpdateChecker(httpClient: client, preferences: prefs,
    comparator: comparator, manifestUrl: manifest, githubOwner: 'pilialvu75-hue',
    githubRepo: repository, targetPlatform: UpdateTargetPlatform.android,
    windowsSetupAssetName: 'AIVEXUS-RendezVous-Setup-x64.exe',
    macosDmgAssetName: 'AIVEXUS-RendezVous-macOS.dmg', linuxDebAssetName: 'AIVEXUS-RendezVous-Linux-amd64.deb');
  final manager = UpdateManager(updateChecker: checker, comparator: comparator,
    preferences: prefs, intentHandler: AndroidIntentHandler(), currentVersion: info.version,
    allowDebugSignatureMismatchBypass: false, enableAndroidBetaBuildNumberComparison: true);
  runApp(MaterialApp(title: 'AIVEXUS RendezVous', theme: ThemeData(colorSchemeSeed: const Color(0xff125566)),
    home: RendezVous(manager: manager, client: client)));
}
class RendezVous extends StatefulWidget {
  const RendezVous({super.key, required this.manager, required this.client});
  final UpdateManager manager;
  final http.Client client;
  @override State<RendezVous> createState() => _RendezVousState();
}
class _RendezVousState extends State<RendezVous> {
  @override void initState() {
    super.initState();
    widget.manager.startBackgroundChecks(interval: const Duration(minutes: 2));
  }
  @override void dispose() {
    widget.manager.dispose(); widget.client.close(); super.dispose();
  }
  Future<void> showUpdates() async {
    await showDialog<void>(context: context, builder: (ctx) => UpdatePanel(manager: widget.manager));
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AIVEXUS RendezVous'), actions: [
      ValueListenableBuilder<UpdateState>(valueListenable: widget.manager.state,
        builder: (_, state, __) => IconButton(tooltip: 'Mises à jour', onPressed: showUpdates,
          icon: Icon(state.hasUpdate || state.status == UpdateStatus.readyToInstall ? Icons.system_update : Icons.update)))
    ]),
    body: const AndroidView(viewType: 'rendezvous/agenda'));
}
class UpdatePanel extends StatelessWidget {
  const UpdatePanel({super.key, required this.manager});
  final UpdateManager manager;
  String label(UpdateStatus s) => switch(s) {
    UpdateStatus.idle => 'Prêt', UpdateStatus.checking => 'Recherche…',
    UpdateStatus.upToDate => 'À jour', UpdateStatus.updateAvailable => 'Mise à jour disponible',
    UpdateStatus.downloading => 'Téléchargement…', UpdateStatus.readyToInstall => 'Prêt à installer',
    UpdateStatus.error => 'Erreur',
  };
  @override Widget build(BuildContext context) => ValueListenableBuilder<UpdateState>(
    valueListenable: manager.state, builder: (ctx, s, _) {
      final busy = s.status == UpdateStatus.checking || s.status == UpdateStatus.downloading;
      return AlertDialog(title: const Text('Mises à jour'), scrollable: true,
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Version installée : ${s.currentVersion}'), Text(label(s.status)),
          if (s.latestManifest != null) Text('Version détectée : ${s.latestManifest!.version}'),
          if (s.usedCachedManifest) const Text('Résultat en cache — connexion à vérifier'),
          if (s.errorMessage != null) Text(s.errorMessage!),
          DropdownButton<ReleaseChannel>(value: s.preferredChannel, isExpanded: true,
            items: [for (final c in ReleaseChannel.values) DropdownMenuItem(value: c, child: Text(c.name))],
            onChanged: busy ? null : (c) { if (c != null) manager.setPreferredChannel(c); }),
          if (s.status == UpdateStatus.downloading) LinearProgressIndicator(value: s.downloadProgress.clamp(0.0, 1.0).toDouble()),
          OutlinedButton(onPressed: busy ? null : () => manager.checkForUpdates(allowCachedFallback: false), child: const Text('Rechercher')),
          if (s.hasUpdate && !s.usedCachedManifest) FilledButton(onPressed: () async {
            final accepted = await showDialog<bool>(context: ctx, builder: (c) => AlertDialog(title: const Text('Télécharger la mise à jour ?'),
              content: const Text('Le module vérifiera le fichier avant de proposer son installation.'), actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
                FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Télécharger'))]));
            if (accepted == true && manager.state.value.latestManifest?.version == s.latestManifest?.version && manager.state.value.hasUpdate) await manager.downloadLatestApk();
          }, child: const Text('Télécharger')),
          if (s.status == UpdateStatus.readyToInstall) FilledButton(onPressed: () => manager.prepareInstallIntent(), child: const Text('Installer')),
          OutlinedButton(onPressed: busy ? null : () => manager.openUnknownAppsSettings(), child: const Text('Autorisation Android')),
          OutlinedButton(onPressed: () => manager.refreshDiagnostics(), child: const Text('Actualiser le diagnostic')),
          Text('APK vérifié/enregistré : ${s.diagnostics.apkDownloaded}'),
          Text('Fichier présent : ${s.diagnostics.apkFileExists}'),
          Text('Autorisation Android : ${s.diagnostics.canRequestPackageInstalls ?? "?"}'),
          Text('Installateur lancé : ${s.diagnostics.installerLaunchSuccess ?? "?"}'),
          if(s.diagnostics.lastException != null) Text(s.diagnostics.lastException!),
          const Text('Pilote expérimental — aucune donnée médicale réelle.')
        ]), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer'))]);
    });
}
